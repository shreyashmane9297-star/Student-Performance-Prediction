import streamlit as st
import pandas as pd
import joblib


# -----------------------------------
# Load Trained Model
# -----------------------------------

model = joblib.load("student_performance_model.pkl")


# -----------------------------------
# Page Configuration
# -----------------------------------

st.set_page_config(
    page_title="Student Performance Prediction",
    page_icon="🎓",
    layout="centered"
)


# -----------------------------------
# Title
# -----------------------------------

st.title("🎓 Student Performance Prediction")

st.write(
    "Enter the student's details below to predict "
    "the final examination score."
)


# -----------------------------------
# Student Inputs
# -----------------------------------

study_hours = st.number_input(
    "📚 Study Hours per Day",
    min_value=0.0,
    max_value=15.0,
    value=6.0,
    step=0.5
)


attendance = st.number_input(
    "🏫 Attendance (%)",
    min_value=0.0,
    max_value=100.0,
    value=80.0,
    step=1.0
)


previous_score = st.number_input(
    "📝 Previous Exam Score",
    min_value=0.0,
    max_value=100.0,
    value=70.0,
    step=1.0
)


assignment_score = st.number_input(
    "📋 Assignment Score",
    min_value=0.0,
    max_value=100.0,
    value=75.0,
    step=1.0
)


sleep_hours = st.number_input(
    "😴 Sleep Hours per Day",
    min_value=0.0,
    max_value=15.0,
    value=8.0,
    step=0.5
)


# -----------------------------------
# Prepare Input Data
# -----------------------------------

new_student = pd.DataFrame({
    "study_hours": [study_hours],
    "attendance": [attendance],
    "previous_score": [previous_score],
    "assignment_score": [assignment_score],
    "sleep_hours": [sleep_hours]
})


# -----------------------------------
# Prediction Button
# -----------------------------------

if st.button("🔮 Predict Final Score"):

    predicted_score = model.predict(new_student)

    score = predicted_score[0]

    st.success(
        f"🎯 Predicted Final Score: {score:.2f} / 100"
    )


# -----------------------------------
# Project Information
# -----------------------------------

st.markdown("---")

st.subheader("📌 About This Project")

st.write(
    "This project uses a Random Forest Regression model "
    "to predict a student's final examination score based "
    "on study hours, attendance, previous score, "
    "assignment performance, and sleep hours."
)